<title>Proof of Concept Endy Ofo</title>
@vite('resources/css/app.css')
